/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/borderify.ts":
/*!**************************!*\
  !*** ./src/borderify.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apply: () => (/* binding */ apply),
/* harmony export */   description: () => (/* binding */ description)
/* harmony export */ });
var description = "Adds a 5px solid red border to the page.";
function apply(doc) {
    doc.body.style.border = "5px solid red";
}


/***/ }),

/***/ "./src/valve-pct-position.ts":
/*!***********************************!*\
  !*** ./src/valve-pct-position.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apply: () => (/* binding */ apply),
/* harmony export */   description: () => (/* binding */ description)
/* harmony export */ });
var valveSelector = "div.css-1ouclyk-percent-percent-Valve-Valve-Valve-Valve-Valve";
var description = "Moves the in-diagram control valve percentages on Lincoln Peak screen over to avoid covering them with their name tags.";
function apply(doc) {
    doc
        .querySelectorAll(valveSelector)
        .forEach(function (elem) { elem.style.left = "85px"; });
    console.log("Fix applied from valve-pct-position.ts.");
}


/***/ }),

/***/ "./src/weather-station-setup.ts":
/*!**************************************!*\
  !*** ./src/weather-station-setup.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   apply: () => (/* binding */ apply),
/* harmony export */   description: () => (/* binding */ description)
/* harmony export */ });
var description = "Sets up a stack of weather station widgets in a logical layout.";
var lpBase = {
    id: "weatherOverlay4",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: 192px; left: -1262px;"
};
var lpMid = {
    id: "weatherOverlay2",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: 618px; left: -1173 px;"
};
var lpSummit = {
    id: "weatherOverlay5",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: 768px; left: -1032px;"
};
var meBase = {
    id: "weatherOverlay3",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: -12px; left: -2429px;"
};
var meMid = {
    id: "weatherOverlay7",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: 301px; left: -2250px;"
};
var meSummit = {
    id: "weatherOverlay6",
    class: "css-84pr04-weatherOverlay-weatherOverlay-WeatherStation",
    style: "visibility: visible; top: 455px; left: -1954px;"
};
function applyConfiguration(weatherStation, doc) {
    var elem = doc.getElementById(weatherStation.id);
    if (elem === null) {
        return;
    }
    else {
        elem.className = weatherStation.class;
        elem.style.cssText = weatherStation.style;
    }
}
function apply(doc) {
    [lpBase, lpMid, lpSummit, meBase, meMid, meSummit]
        .forEach(function (station) { return applyConfiguration(station, document); });
}


/***/ }),

/***/ "./node_modules/ts-pattern/dist/index.js":
/*!***********************************************!*\
  !*** ./node_modules/ts-pattern/dist/index.js ***!
  \***********************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ _),
/* harmony export */   Pattern: () => (/* binding */ _),
/* harmony export */   isMatching: () => (/* binding */ a),
/* harmony export */   match: () => (/* binding */ N)
/* harmony export */ });
const t=Symbol.for("@ts-pattern/matcher"),e=Symbol.for("@ts-pattern/isVariadic"),n="@ts-pattern/anonymous-select-key",r=t=>Boolean(t&&"object"==typeof t),i=e=>e&&!!e[t],s=(n,o,c)=>{if(i(n)){const e=n[t](),{matched:r,selections:i}=e.match(o);return r&&i&&Object.keys(i).forEach(t=>c(t,i[t])),r}if(r(n)){if(!r(o))return!1;if(Array.isArray(n)){if(!Array.isArray(o))return!1;let t=[],r=[],a=[];for(const s of n.keys()){const o=n[s];i(o)&&o[e]?a.push(o):a.length?r.push(o):t.push(o)}if(a.length){if(a.length>1)throw new Error("Pattern error: Using `...P.array(...)` several times in a single pattern is not allowed.");if(o.length<t.length+r.length)return!1;const e=o.slice(0,t.length),n=0===r.length?[]:o.slice(-r.length),i=o.slice(t.length,0===r.length?Infinity:-r.length);return t.every((t,n)=>s(t,e[n],c))&&r.every((t,e)=>s(t,n[e],c))&&(0===a.length||s(a[0],i,c))}return n.length===o.length&&n.every((t,e)=>s(t,o[e],c))}return Object.keys(n).every(e=>{const r=n[e];return(e in o||i(a=r)&&"optional"===a[t]().matcherType)&&s(r,o[e],c);var a})}return Object.is(o,n)},o=e=>{var n,s,a;return r(e)?i(e)?null!=(n=null==(s=(a=e[t]()).getSelectionKeys)?void 0:s.call(a))?n:[]:Array.isArray(e)?c(e,o):c(Object.values(e),o):[]},c=(t,e)=>t.reduce((t,n)=>t.concat(e(n)),[]);function a(...t){if(1===t.length){const[e]=t;return t=>s(e,t,()=>{})}if(2===t.length){const[e,n]=t;return s(e,n,()=>{})}throw new Error(`isMatching wasn't given the right number of arguments: expected 1 or 2, received ${t.length}.`)}function u(t){return Object.assign(t,{optional:()=>l(t),and:e=>m(t,e),or:e=>y(t,e),select:e=>void 0===e?p(t):p(e,t)})}function h(t){return Object.assign((t=>Object.assign(t,{*[Symbol.iterator](){yield Object.assign(t,{[e]:!0})}}))(t),{optional:()=>h(l(t)),select:e=>h(void 0===e?p(t):p(e,t))})}function l(e){return u({[t]:()=>({match:t=>{let n={};const r=(t,e)=>{n[t]=e};return void 0===t?(o(e).forEach(t=>r(t,void 0)),{matched:!0,selections:n}):{matched:s(e,t,r),selections:n}},getSelectionKeys:()=>o(e),matcherType:"optional"})})}const f=(t,e)=>{for(const n of t)if(!e(n))return!1;return!0},g=(t,e)=>{for(const[n,r]of t.entries())if(!e(r,n))return!1;return!0};function m(...e){return u({[t]:()=>({match:t=>{let n={};const r=(t,e)=>{n[t]=e};return{matched:e.every(e=>s(e,t,r)),selections:n}},getSelectionKeys:()=>c(e,o),matcherType:"and"})})}function y(...e){return u({[t]:()=>({match:t=>{let n={};const r=(t,e)=>{n[t]=e};return c(e,o).forEach(t=>r(t,void 0)),{matched:e.some(e=>s(e,t,r)),selections:n}},getSelectionKeys:()=>c(e,o),matcherType:"or"})})}function d(e){return{[t]:()=>({match:t=>({matched:Boolean(e(t))})})}}function p(...e){const r="string"==typeof e[0]?e[0]:void 0,i=2===e.length?e[1]:"string"==typeof e[0]?void 0:e[0];return u({[t]:()=>({match:t=>{let e={[null!=r?r:n]:t};return{matched:void 0===i||s(i,t,(t,n)=>{e[t]=n}),selections:e}},getSelectionKeys:()=>[null!=r?r:n].concat(void 0===i?[]:o(i))})})}function v(t){return"number"==typeof t}function b(t){return"string"==typeof t}function w(t){return"bigint"==typeof t}const S=u(d(function(t){return!0})),O=S,j=t=>Object.assign(u(t),{startsWith:e=>{return j(m(t,(n=e,d(t=>b(t)&&t.startsWith(n)))));var n},endsWith:e=>{return j(m(t,(n=e,d(t=>b(t)&&t.endsWith(n)))));var n},minLength:e=>j(m(t,(t=>d(e=>b(e)&&e.length>=t))(e))),maxLength:e=>j(m(t,(t=>d(e=>b(e)&&e.length<=t))(e))),includes:e=>{return j(m(t,(n=e,d(t=>b(t)&&t.includes(n)))));var n},regex:e=>{return j(m(t,(n=e,d(t=>b(t)&&Boolean(t.match(n))))));var n}}),E=j(d(b)),K=t=>Object.assign(u(t),{between:(e,n)=>K(m(t,((t,e)=>d(n=>v(n)&&t<=n&&e>=n))(e,n))),lt:e=>K(m(t,(t=>d(e=>v(e)&&e<t))(e))),gt:e=>K(m(t,(t=>d(e=>v(e)&&e>t))(e))),lte:e=>K(m(t,(t=>d(e=>v(e)&&e<=t))(e))),gte:e=>K(m(t,(t=>d(e=>v(e)&&e>=t))(e))),int:()=>K(m(t,d(t=>v(t)&&Number.isInteger(t)))),finite:()=>K(m(t,d(t=>v(t)&&Number.isFinite(t)))),positive:()=>K(m(t,d(t=>v(t)&&t>0))),negative:()=>K(m(t,d(t=>v(t)&&t<0)))}),A=K(d(v)),x=t=>Object.assign(u(t),{between:(e,n)=>x(m(t,((t,e)=>d(n=>w(n)&&t<=n&&e>=n))(e,n))),lt:e=>x(m(t,(t=>d(e=>w(e)&&e<t))(e))),gt:e=>x(m(t,(t=>d(e=>w(e)&&e>t))(e))),lte:e=>x(m(t,(t=>d(e=>w(e)&&e<=t))(e))),gte:e=>x(m(t,(t=>d(e=>w(e)&&e>=t))(e))),positive:()=>x(m(t,d(t=>w(t)&&t>0))),negative:()=>x(m(t,d(t=>w(t)&&t<0)))}),P=x(d(w)),T=u(d(function(t){return"boolean"==typeof t})),k=u(d(function(t){return"symbol"==typeof t})),B=u(d(function(t){return null==t}));var _={__proto__:null,matcher:t,optional:l,array:function(...e){return h({[t]:()=>({match:t=>{if(!Array.isArray(t))return{matched:!1};if(0===e.length)return{matched:!0};const n=e[0];let r={};if(0===t.length)return o(n).forEach(t=>{r[t]=[]}),{matched:!0,selections:r};const i=(t,e)=>{r[t]=(r[t]||[]).concat([e])};return{matched:t.every(t=>s(n,t,i)),selections:r}},getSelectionKeys:()=>0===e.length?[]:o(e[0])})})},set:function(...e){return u({[t]:()=>({match:t=>{if(!(t instanceof Set))return{matched:!1};let n={};if(0===t.size)return{matched:!0,selections:n};if(0===e.length)return{matched:!0};const r=(t,e)=>{n[t]=(n[t]||[]).concat([e])},i=e[0];return{matched:f(t,t=>s(i,t,r)),selections:n}},getSelectionKeys:()=>0===e.length?[]:o(e[0])})})},map:function(...e){return u({[t]:()=>({match:t=>{if(!(t instanceof Map))return{matched:!1};let n={};if(0===t.size)return{matched:!0,selections:n};const r=(t,e)=>{n[t]=(n[t]||[]).concat([e])};if(0===e.length)return{matched:!0};var i;if(1===e.length)throw new Error(`\`P.map\` wasn't given enough arguments. Expected (key, value), received ${null==(i=e[0])?void 0:i.toString()}`);const[o,c]=e;return{matched:g(t,(t,e)=>{const n=s(o,e,r),i=s(c,t,r);return n&&i}),selections:n}},getSelectionKeys:()=>0===e.length?[]:[...o(e[0]),...o(e[1])]})})},intersection:m,union:y,not:function(e){return u({[t]:()=>({match:t=>({matched:!s(e,t,()=>{})}),getSelectionKeys:()=>[],matcherType:"not"})})},when:d,select:p,any:S,_:O,string:E,number:A,bigint:P,boolean:T,symbol:k,nullish:B,instanceOf:function(t){return u(d(function(t){return e=>e instanceof t}(t)))},shape:function(t){return u(d(a(t)))}};const W={matched:!1,value:void 0};function N(t){return new $(t,W)}class ${constructor(t,e){this.input=void 0,this.state=void 0,this.input=t,this.state=e}with(...t){if(this.state.matched)return this;const e=t[t.length-1],r=[t[0]];let i;3===t.length&&"function"==typeof t[1]?i=t[1]:t.length>2&&r.push(...t.slice(1,t.length-1));let o=!1,c={};const a=(t,e)=>{o=!0,c[t]=e},u=!r.some(t=>s(t,this.input,a))||i&&!Boolean(i(this.input))?W:{matched:!0,value:e(o?n in c?c[n]:c:this.input,this.input)};return new $(this.input,u)}when(t,e){if(this.state.matched)return this;const n=Boolean(t(this.input));return new $(this.input,n?{matched:!0,value:e(this.input,this.input)}:W)}otherwise(t){return this.state.matched?this.state.value:t(this.input)}exhaustive(){if(this.state.matched)return this.state.value;let t;try{t=JSON.stringify(this.input)}catch(e){t=this.input}throw new Error(`Pattern matching error: no pattern matches value ${t}`)}run(){return this.exhaustive()}returnType(){return this}}
//# sourceMappingURL=index.js.map


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*********************!*\
  !*** ./src/core.ts ***!
  \*********************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Tweak: () => (/* binding */ Tweak),
/* harmony export */   applyProfile: () => (/* binding */ applyProfile),
/* harmony export */   getTweak: () => (/* binding */ getTweak)
/* harmony export */ });
/* harmony import */ var ts_pattern__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ts-pattern */ "./node_modules/ts-pattern/dist/index.js");
/* harmony import */ var _borderify__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./borderify */ "./src/borderify.ts");
/* harmony import */ var _valve_pct_position__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./valve-pct-position */ "./src/valve-pct-position.ts");
/* harmony import */ var _weather_station_setup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./weather-station-setup */ "./src/weather-station-setup.ts");




var Tweak;
(function (Tweak) {
    Tweak["Borderify"] = "borderify";
    Tweak["ValvePctPosition"] = "valve-pct-position";
    Tweak["WeatherStationSetup"] = "weather-station-setup";
})(Tweak || (Tweak = {}));
function getTweak(tweak) {
    return (0,ts_pattern__WEBPACK_IMPORTED_MODULE_0__.match)(tweak)
        .with(Tweak.Borderify, function () { return _borderify__WEBPACK_IMPORTED_MODULE_1__; })
        .with(Tweak.ValvePctPosition, function () { return _valve_pct_position__WEBPACK_IMPORTED_MODULE_2__; })
        .with(Tweak.WeatherStationSetup, function () { return _weather_station_setup__WEBPACK_IMPORTED_MODULE_3__; })
        .exhaustive();
}
function applyProfile(profile, doc) { profile.settings.forEach(function (t) { return getTweak(t).apply(doc); }); }
var testProfile = {
    id: "Test",
    settings: Object.values(Tweak)
};
applyProfile(testProfile, document);

})();

/******/ })()
;
//# sourceMappingURL=main.js.map